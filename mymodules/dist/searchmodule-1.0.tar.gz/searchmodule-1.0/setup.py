from setuptools import setup

setup(
    name='searchmodule',
    version='1.0',
    description='Search tools for the book Python',
    author='mprzybysz',
    author_email='mprzybysz.dev@gmail.com',
    url='mprzybysz.pl',
    py_modules=['searchmodule']
)